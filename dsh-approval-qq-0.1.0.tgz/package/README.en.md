# dsh-approval-qq

**Forward DeepSeek Harness approval prompts to QQ.** When the model needs elevated
permissions, you get a private QQ message with the command and the reason — reply
"同意" (approve) or "拒绝" (reject) from your phone. The desktop dialog stays in
parallel; whichever decides first wins and the other side disappears.

- Standalone plugin: talks to **OneBot v11** (NapCat / Lagrange / LLOneBot…)
  directly — no QQ bot plugin required;
- Zero runtime deps: Node built-in `fetch` / `WebSocket` (Node ≥ 22);
- Only the configured admin QQ can approve; everyone else is ignored;
- If QQ is unavailable it falls back to the desktop prompt — it never hangs a request.

## Install

```bash
dsh plugin add dsh-approval-qq          # from npm, if published
dsh plugin add github:<user>/dsh-approval-qq
dsh plugin add file:/path/to/dsh-approval-qq
```

Restart DSH once, then configure under **Settings → Plugins → dsh-approval-qq**.

## Configure

| Field | Default | Meaning |
|---|---|---|
| `adminQq` | `0` | **Required.** Admin QQ number. |
| `onebotHttpUrl` | `http://127.0.0.1:3000` | OneBot HTTP API (send/recall). |
| `onebotHttpToken` | empty | HTTP `access_token`. |
| `onebotWsUrl` | `ws://127.0.0.1:3001` | Forward WebSocket (receive replies). |
| `onebotWsToken` | empty | WS `access_token` (`?access_token=`). |
| `idLength` | `6` | Approval id length (4–8). |
| `showFullCommand` | `true` | `false` truncates the command at 800 chars. |
| `notifyUnauthorized` | `true` | Reply "no permission" to non-admin approvers. |
| `logFile` | empty | Defaults to `~/.dsh/approval-qq/approval.log`. |

## How it works

```
DSH approval/request (policy=ask)
  ├─ this plugin: send a QQ private message (id + plain-language reason + verbatim command)
  └─ next(): delegate to the next answerer (usually the desktop dialog)

Promise.race → first decision wins; the QQ message is recalled either way.
```

The verbatim command comes from a `tools/pre-execute` hook (the approval request
itself only carries a justification). `displayReason` may be a `{zh,en}` object and is
flattened into plain text. Dangerous patterns (delete / format / system dirs / spawn)
add a `⚠️` warning line.

## Security

- No personal data is baked in: `adminQq` defaults to `0` and must be configured;
- Only `adminQq` replies can grant anything;
- Requests go through your local OneBot server; logs may contain command text —
  keep `~/.dsh/approval-qq/approval.log` out of version control.

## License

MIT
