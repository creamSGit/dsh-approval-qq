# Changelog

## 0.1.0 — 2026-10-26

首个开源版本，从个人自用的 `dsh-onebot-qq` 子插件重写为**独立插件**：

- 不再依赖 `dsh-onebot-qq`：直接对接 OneBot v11 HTTP（发消息/撤回）与正向 WebSocket（收回复）；
- 不需要给任何内核打补丁（作为独立插件直接注册 `approval/request` answerer 与 `tools/pre-execute`）；
- 零运行时依赖（Node ≥ 22 内置 fetch / WebSocket）；
- 配置里**不包含**任何个人信息：`adminQq` 默认 0，必须自己填；
- QQ 与电脑端并行、谁先决定谁生效、另一端撤回；
- QQ 不可用（WS 未连接 / 发送失败 / 异常）时立即退回桌面，不悬挂请求；
- 消息包含：要做的事、工作目录、人话理由、命令原文、危险操作警示、短编号；
- 回复「同意 / 拒绝」即可，多条时默认处理最新一条，也可带编号指定；
- 日志 `~/.dsh/approval-qq/approval.log`（asked / reply / decided / qq-unavailable）。
