/**
 * dsh-approval-qq — 把 DSH 的 ask 审批转发到 QQ，让手机也能「同意 / 拒绝」。
 *
 * 独立插件：不依赖 dsh-onebot-qq 或任何 QQ 机器人插件，直接对接 OneBot v11
 * （NapCat / Lagrange / LLOneBot 等）的 HTTP API 与正向 WebSocket。
 *
 * 工作方式：
 *   DSH 触发 approval/request（policy=ask）
 *     ├─ 本插件向管理员的 QQ 私聊发一条审批消息（短 id + 命令 + 理由）
 *     └─ 同时 next() 放行给电脑端弹窗（如果组合里有桌面 answerer）
 *   谁先决定谁生效：QQ 回复 → 撤回 QQ 消息；电脑点掉 → 也撤回 QQ 消息。
 *
 * 安全边界：
 *   · 只认配置里的 adminQq；其他人回复一律忽略（可选回一条「无权限」提示）；
 *   · QQ 发送失败 / WebSocket 未连接 / 任何异常 → 立即 next() 退回桌面，绝不挂住请求；
 *   · 不设超时；发一次，安静等待。
 *
 * 无第三方运行时依赖：只用 Node 内置 fetch / WebSocket（Node >= 22）。
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'
import z from '@deepseek-ai/schemastery'

export const name = 'approval-qq'
export const inject = []

const WEEK_ZH = ['日', '一', '二', '三', '四', '五', '六']
const ACTION_RE = /^(同意|允许|通过|批准|拒绝|驳回|不行)\s*([0-9a-f]{4,8})?$/i
const YES_RE = /^(同意|允许|通过|批准)/

const MODE_ZH = {
  'read-only': '只读',
  'workspace-write': '仅工作区可写',
  'danger-full-access': '完全访问（可以修改系统任何位置）',
}

const TOOL_ZH = {
  pwsh: '执行一条 PowerShell 命令',
  bash: '执行一条终端命令',
  fs: '读写文件',
  write: '写文件',
  edit: '修改文件',
}

const DANGER = [
  [/rm\s+-rf|remove-item[^\n]*-recurse|del\s+\/[sq]|rmdir\s+\/s/i, '删除文件/目录'],
  [/format\s+[a-z]:|format-volume|clear-disk/i, '格式化磁盘'],
  [/>\s*[a-z]:\\|out-file|set-content|add-content/i, '覆盖/写入文件'],
  [/c:\\windows|c:\\program files|system32|programdata/i, '写入系统目录'],
  [/start-process|\.exe(\s|$)|java\s+-jar|schtasks\s+\/create|reg\s+(add|delete)/i, '启动进程/改系统配置'],
  [/git\s+push\s+--force|drop\s+table|truncate/i, '强制推送/破坏性数据操作'],
]

function beijing(ms) {
  const d = new Date(Number(ms || Date.now()) + 8 * 3600 * 1000)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}-${p(d.getUTCDate())} `
    + `${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())} 周${WEEK_ZH[d.getUTCDay()]}`
}

function truncate(s, n) {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim()
  return t.length > n ? `${t.slice(0, n)}…` : t
}

/** displayReason 可能是字符串、{zh,en} 或其它对象；统一压成一句人话 */
function reasonText(req) {
  const d = req?.displayReason
  if (typeof d === 'string' && d.trim()) return d.trim()
  if (d && typeof d === 'object') {
    for (const k of ['zh', 'en']) {
      if (typeof d[k] === 'string' && d[k].trim()) return d[k].trim()
    }
    for (const v of Object.values(d)) {
      if (typeof v === 'string' && v.trim()) return v.trim()
    }
  }
  if (typeof req?.reason === 'string' && req.reason.trim()) return req.reason.trim()
  return ''
}

function parseEscalation(req) {
  const m = /escalate sandbox to (\S+?)[:：]\s*([\s\S]*)$/i.exec(String(req?.reason || ''))
  return m ? { mode: m[1], justification: (m[2] || '').trim() } : null
}

function dangerHits(text) {
  const hits = []
  for (const [re, label] of DANGER) if (re.test(text)) hits.push(label)
  return [...new Set(hits)]
}

export const Config = z.object({
  adminQq: z.number().default(0)
    .description('审批人 QQ 号（必填）。只有这个账号的私聊回复会被接受。'),
  onebotHttpUrl: z.string().default('http://127.0.0.1:3000')
    .description('OneBot v11 HTTP API 地址，例如 http://127.0.0.1:3000'),
  onebotHttpToken: z.string().role('secret').default('')
    .description('HTTP API 的 access_token（没有就留空）'),
  onebotWsUrl: z.string().default('ws://127.0.0.1:3001')
    .description('OneBot v11 正向 WebSocket 地址，用来接收你的回复'),
  onebotWsToken: z.string().role('secret').default('')
    .description('WebSocket 的 access_token（没有就留空）'),
  idLength: z.number().default(6)
    .description('审批编号长度（4~8），消息里的 #xxxxxx'),
  showFullCommand: z.boolean().default(true)
    .description('true 原样贴完整命令；false 只贴前 800 字'),
  notifyUnauthorized: z.boolean().default(true)
    .description('其他人回复审批词时，是否私聊回一句「无权限」'),
  logFile: z.string().default('')
    .description('日志路径，留空 = ~/.dsh/approval-qq/approval.log'),
})

export function apply(ctx, config) {
  const cfg = config || {}
  const log = ctx.logger
  const adminQq = String(Number(cfg.adminQq) || 0)
  if (!adminQq || adminQq === '0') {
    log.warn('[approval-qq] 未配置 adminQq，插件不生效（审批只在电脑端进行）')
    return
  }

  const idLen = Math.max(4, Math.min(8, Number(cfg.idLength) || 6))
  const fullCommand = cfg.showFullCommand !== false
  const httpBase = String(cfg.onebotHttpUrl || '').replace(/\/+$/, '')
  const httpToken = String(cfg.onebotHttpToken || '')
  const logFile = cfg.logFile
    ? String(cfg.logFile)
    : path.join(os.homedir(), '.dsh', 'approval-qq', 'approval.log')
  try { fs.mkdirSync(path.dirname(logFile), { recursive: true }) } catch { /* 写日志时再报 */ }

  /** id -> { id, resolve, req, messageId, at } */
  const pending = new Map()
  /** callId -> { name, args }：从 tools/pre-execute 抓原始参数，用于还原命令原文 */
  const callCache = new Map()
  let wsUp = false

  const writeLog = (rec) => {
    try {
      fs.appendFileSync(logFile, `${JSON.stringify({ at: beijing(), ...rec })}\n`, 'utf8')
    } catch (e) {
      log.warn(`[approval-qq] 写日志失败: ${e.message}`)
    }
  }

  // ── OneBot HTTP ────────────────────────────────────────────────
  async function onebot(action, body) {
    if (!httpBase) throw new Error('onebotHttpUrl 未配置')
    const headers = { 'content-type': 'application/json' }
    if (httpToken) headers.authorization = `Bearer ${httpToken}`
    const res = await fetch(`${httpBase}/${action}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15000),
    })
    const json = await res.json().catch(() => null)
    if (!res.ok || (json && json.status === 'failed')) {
      throw new Error(`OneBot ${action} 失败：${res.status} ${json?.message || json?.wording || ''}`.trim())
    }
    return json?.data
  }

  const sendPrivate = (qq, text) => onebot('send_private_msg', { user_id: Number(qq), message: text })
  const recall = (messageId) => onebot('delete_msg', { message_id: Number(messageId) })

  // ── OneBot WebSocket（收回复） ─────────────────────────────────
  const wsToken = String(cfg.onebotWsToken || '')
  let wsUrl = String(cfg.onebotWsUrl || '')
  if (wsUrl && wsToken) {
    const u = new URL(wsUrl)
    u.searchParams.set('access_token', wsToken)
    wsUrl = u.toString()
  }

  let stopped = false
  let retryTimer = null
  let socket = null

  function handleEvent(ev) {
    try {
      if (!ev || ev.post_type !== 'message' || ev.message_type !== 'private') return
      const from = String(ev.user_id || '')
      const raw = String(ev.raw_message ?? '')
      // 去掉 CQ 码，只留文本
      const text = raw.replace(/\[CQ:[^\]]*\]/g, '').trim()
      const m = ACTION_RE.exec(text)

      if (from !== adminQq) {
        if (m && pending.size > 0 && cfg.notifyUnauthorized !== false) {
          sendPrivate(from, '（无权限）只有管理员能处理审批，已忽略。').catch(() => {})
        }
        return
      }
      if (!m || pending.size === 0) return

      const yes = YES_RE.test(m[1])
      const keys = [...pending.keys()]
      const wanted = (m[2] || '').toLowerCase()
      const id = wanted || keys[keys.length - 1]
      const entry = pending.get(id)
      if (!entry) {
        sendPrivate(adminQq, `编号 ${id} 不存在或已处理。当前待审批：${keys.map((k) => '#' + k).join('、') || '（无）'}`).catch(() => {})
        return
      }
      const rest = keys.filter((k) => k !== id)
      pending.delete(id)
      entry.resolve(yes ? 'allowed-once' : 'rejected')
      const extra = (!wanted && rest.length > 0)
        ? `（默认处理了最新一条，还有 ${rest.length} 条：${rest.map((k) => '#' + k).join('、')}）`
        : ''
      sendPrivate(adminQq, `已${yes ? '同意' : '拒绝'} #${id}${extra}`).catch(() => {})
      writeLog({ id, phase: 'reply', qq: from, decision: yes ? 'allowed-once' : 'rejected' })
    } catch (e) {
      log.warn(`[approval-qq] 处理 WS 事件失败：${e.message}`)
    }
  }

  function connect() {
    if (stopped || !wsUrl) return
    try {
      socket = new WebSocket(wsUrl)
    } catch (e) {
      log.warn(`[approval-qq] WebSocket 创建失败：${e.message}`)
      scheduleRetry()
      return
    }
    socket.onopen = () => {
      wsUp = true
      log.info('[approval-qq] OneBot WebSocket 已连接')
    }
    socket.onmessage = (ev) => {
      try { handleEvent(JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data))) }
      catch { /* 非 JSON 帧忽略 */ }
    }
    socket.onerror = () => { try { socket?.close() } catch { /* ignore */ } }
    socket.onclose = () => {
      wsUp = false
      if (!stopped) scheduleRetry()
    }
  }

  function scheduleRetry() {
    if (retryTimer || stopped) return
    retryTimer = setTimeout(() => {
      retryTimer = null
      connect()
    }, 3000)
  }

  if (wsUrl) connect()
  else log.warn('[approval-qq] onebotWsUrl 未配置：只能发审批消息，收不到回复，将退回电脑端')

  // ── 抓工具原始参数（DSH 的审批请求不带命令） ───────────────────
  try {
    ctx.on('tools/pre-execute', (exec, next) => {
      try {
        if (exec?.callId) {
          callCache.set(String(exec.callId), { name: exec.name, args: exec.arguments })
          while (callCache.size > 50) callCache.delete(callCache.keys().next().value)
        }
      } catch { /* 抓不到就只显示理由 */ }
      return next()
    }, { prepend: true })
  } catch (e) {
    log.warn(`[approval-qq] 挂 tools/pre-execute 失败：${e.message}`)
  }

  function commandOf(req) {
    const hit = req?.callId ? callCache.get(String(req.callId)) : null
    const args = hit?.args || {}
    const raw = args.command ?? args.cmd ?? args.text ?? args.content ?? ''
    if (typeof raw === 'string' && raw.trim()) return { text: raw, source: 'args' }
    if (hit?.args) {
      try { return { text: JSON.stringify(hit.args, null, 2), source: 'args-json' } } catch { /* fallthrough */ }
    }
    return { text: '', source: 'none' }
  }

  function buildMessage(id, req) {
    const cmd = commandOf(req)
    const esc = parseEscalation(req)
    const tool = req?.toolName || '?'
    const what = TOOL_ZH[tool] || `调用工具 ${tool}`
    const explain = esc?.justification || reasonText(req) || '（DSH 没有提供说明）'
    const cwd = req?.agent?.session?.header?.cwd || ''
    const lines = []

    lines.push(`【审批 #${id}】需要你点头才能继续`)
    lines.push('')
    lines.push(`我要做什么：${what}`)
    if (cwd) lines.push(`在哪个目录：${cwd}`)
    if (esc) {
      lines.push(`为什么要你同意：要临时把沙箱提到「${MODE_ZH[esc.mode] || esc.mode}」，DSH 规定提权必须本人确认。`)
    } else {
      lines.push('为什么要你同意：这个操作被 DSH 判定为需要授权。')
    }
    lines.push(`理由：${explain}`)
    lines.push('')

    if (cmd.text) {
      const shown = fullCommand ? cmd.text : `${cmd.text.slice(0, 800)}\n…（已截断）`
      lines.push('命令（原样）：')
      lines.push(shown)
    } else {
      lines.push('命令：本条请求没有携带可展示的命令原文（只拿到了理由）。')
    }

    const danger = dangerHits(`${cmd.text}\n${explain}\n${req?.reason || ''}`)
    if (danger.length) {
      lines.push('')
      lines.push(`⚠️ 危险操作：${danger.join(' / ')}——看清楚再同意`)
    }

    lines.push('')
    lines.push(`时间：${beijing()}`)
    lines.push('——————')
    lines.push('回复「同意」或「拒绝」即可（多条时默认处理最新一条；要指定也可加编号）')
    return lines.join('\n')
  }

  function askQQ(req) {
    const id = crypto.randomBytes(4).toString('hex').slice(0, idLen)
    let entry
    const promise = new Promise((resolve) => {
      entry = { id, resolve, req, messageId: null, at: Date.now() }
      pending.set(id, entry)
    })
    const cmd = commandOf(req)
    writeLog({
      id, phase: 'asked', tool: req?.toolName,
      reason: req?.reason, cmd: cmd.text ? cmd.text.slice(0, 400) : '', cmdSource: cmd.source,
    })
    sendPrivate(adminQq, buildMessage(id, req))
      .then((data) => { entry.messageId = data?.message_id ?? null })
      .catch((e) => {
        log.warn(`[approval-qq] 发送失败，退回桌面：${e.message}`)
        pending.delete(id)
        writeLog({ id, phase: 'qq-unavailable', error: e.message })
        entry.resolve(null)
      })
    return { id, entry, promise }
  }

  async function recallQuiet(messageId) {
    if (!messageId) return
    try { await recall(messageId) } catch { /* 撤回失败不影响结果 */ }
  }

  // ── answerer：QQ 与电脑端并行 ─────────────────────────────────
  ctx.on('approval/request', async (req, next) => {
    // WS 没连上 = 收不到回复，直接交给桌面，避免发出去了没人能批
    if (!wsUp) return next()

    let asked
    try { asked = askQQ(req) }
    catch (e) {
      log.warn(`[approval-qq] 初始化失败，退回桌面：${e.message}`)
      return next()
    }
    const desktop = Promise.resolve(next())
    const qqSide = asked.promise.then((o) => (o == null ? null : { src: 'qq', outcome: o }))
    let won = await Promise.race([qqSide, desktop.then((o) => ({ src: 'desktop', outcome: o }))])
    if (won == null) won = await desktop.then((o) => ({ src: 'desktop', outcome: o }))

    pending.delete(asked.id)
    await recallQuiet(asked.entry.messageId)
    writeLog({ id: asked.id, phase: 'decided', tool: req?.toolName, source: won.src, outcome: won.outcome })
    log.info(`[approval-qq] #${asked.id} ${won.outcome}（${won.src}）`)
    return won.outcome
  }, { prepend: true })

  // ── 清理：停止重连、关闭 socket ───────────────────────────────
  ctx.effect(() => () => {
    stopped = true
    if (retryTimer) clearTimeout(retryTimer)
    try { socket?.close() } catch { /* ignore */ }
    for (const [, e] of pending) e.resolve(null)
    pending.clear()
  })

  log.info(`[approval-qq] 已启用：审批人 QQ ${adminQq}，OneBot ${httpBase}`)
}
